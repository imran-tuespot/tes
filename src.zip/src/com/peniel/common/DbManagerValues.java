package com.peniel.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * User: todds
 * Date: 11/4/11
 * Time: 12:32 PM
 */
public class DbManagerValues {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbManagerValues.class);

    public static final String CONN_SOURCE = "orcfprod";
}
