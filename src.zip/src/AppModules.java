import java.util.List;


public class AppModules {
	
	private List<ModuleResponse> moduleDetails;

	public List<ModuleResponse> getModuleDetails() {
		return moduleDetails;
	}

	public void setModuleDetails(List<ModuleResponse> moduleDetails) {
		this.moduleDetails = moduleDetails;
	}

	
	
	
}
